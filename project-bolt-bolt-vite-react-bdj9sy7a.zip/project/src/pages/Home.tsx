import React from 'react'
import { Github, Twitter, Mail } from 'lucide-react'

const Home = () => {
  return (
    <div className="min-h-screen pt-24 px-4">
      <div className="max-w-2xl mx-auto">
        <h1 className="text-4xl font-bold mb-6">Hello, I'm Koharshal</h1>
        <p className="text-zinc-300 text-lg mb-8">
          I write about technology, life, and everything in between. Here you'll find my thoughts, 
          reading lists, and musical interests.
        </p>
        <div className="flex space-x-6">
          <a href="https://github.com" target="_blank" rel="noopener noreferrer" 
             className="hover:text-zinc-300 transition">
            <Github size={24} />
          </a>
          <a href="https://twitter.com" target="_blank" rel="noopener noreferrer"
             className="hover:text-zinc-300 transition">
            <Twitter size={24} />
          </a>
          <a href="mailto:contact@example.com"
             className="hover:text-zinc-300 transition">
            <Mail size={24} />
          </a>
        </div>
      </div>
    </div>
  )
}

export default Home