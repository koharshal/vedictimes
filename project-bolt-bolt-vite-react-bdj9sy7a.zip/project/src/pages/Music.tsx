import React from 'react'
import { Headphones } from 'lucide-react'

const Music = () => {
  const playlists = [
    {
      title: "Coding Focus",
      description: "Ambient electronic music for deep work sessions",
      tracks: 42
    },
    {
      title: "Evening Jazz",
      description: "Relaxing jazz collection for unwinding",
      tracks: 35
    }
  ]

  return (
    <div className="min-h-screen pt-24 px-4">
      <div className="max-w-2xl mx-auto">
        <h1 className="text-3xl font-bold mb-8">Music Collection</h1>
        <div className="space-y-6">
          {playlists.map((playlist, index) => (
            <div key={index} className="flex items-start space-x-4 border-b border-zinc-800 pb-6">
              <Headphones className="mt-1" size={20} />
              <div>
                <h2 className="text-xl font-semibold">{playlist.title}</h2>
                <p className="text-zinc-300">{playlist.description}</p>
                <p className="text-zinc-400 text-sm mt-1">{playlist.tracks} tracks</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

export default Music