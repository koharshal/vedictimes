import React from 'react'
import { BookOpen } from 'lucide-react'

const Readings = () => {
  const books = [
    {
      title: "Atomic Habits",
      author: "James Clear",
      status: "Currently Reading"
    },
    {
      title: "The Pragmatic Programmer",
      author: "Dave Thomas, Andy Hunt",
      status: "Completed"
    }
  ]

  return (
    <div className="min-h-screen pt-24 px-4">
      <div className="max-w-2xl mx-auto">
        <h1 className="text-3xl font-bold mb-8">Reading List</h1>
        <div className="space-y-6">
          {books.map((book, index) => (
            <div key={index} className="flex items-start space-x-4 border-b border-zinc-800 pb-6">
              <BookOpen className="mt-1" size={20} />
              <div>
                <h2 className="text-xl font-semibold">{book.title}</h2>
                <p className="text-zinc-300">{book.author}</p>
                <p className="text-zinc-400 text-sm mt-1">{book.status}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

export default Readings