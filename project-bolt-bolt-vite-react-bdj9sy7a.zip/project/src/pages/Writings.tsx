import React from 'react'

const Writings = () => {
  const posts = [
    {
      title: "Thoughts on Modern Development",
      date: "March 2024",
      excerpt: "Exploring the current state of software development and where we're headed."
    },
    {
      title: "The Art of Minimalism",
      date: "February 2024",
      excerpt: "Less is more - how minimalism influences design and life."
    }
  ]

  return (
    <div className="min-h-screen pt-24 px-4">
      <div className="max-w-2xl mx-auto">
        <h1 className="text-3xl font-bold mb-8">Writings</h1>
        <div className="space-y-8">
          {posts.map((post, index) => (
            <article key={index} className="border-b border-zinc-800 pb-6">
              <h2 className="text-xl font-semibold mb-2">{post.title}</h2>
              <p className="text-zinc-400 text-sm mb-3">{post.date}</p>
              <p className="text-zinc-300">{post.excerpt}</p>
            </article>
          ))}
        </div>
      </div>
    </div>
  )
}

export default Writings