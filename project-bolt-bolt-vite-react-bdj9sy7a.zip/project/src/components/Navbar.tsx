import React from 'react'
import { Link, useLocation } from 'react-router-dom'
import { PenLine, BookOpen, Music } from 'lucide-react'

const Navbar = () => {
  const location = useLocation()
  
  const isActive = (path: string) => {
    return location.pathname === path ? 'border-white' : 'border-transparent'
  }

  return (
    <nav className="fixed w-full bg-zinc-900/90 backdrop-blur-sm border-b border-zinc-800">
      <div className="max-w-5xl mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <Link to="/" className="text-xl font-medium hover:text-zinc-300 transition">
            koharshal
          </Link>
          <div className="flex items-center space-x-8">
            <Link 
              to="/writings" 
              className={`flex items-center space-x-2 border-b-2 ${isActive('/writings')} pb-1 hover:text-zinc-300 transition`}
            >
              <PenLine size={18} />
              <span>Writings</span>
            </Link>
            <Link 
              to="/readings" 
              className={`flex items-center space-x-2 border-b-2 ${isActive('/readings')} pb-1 hover:text-zinc-300 transition`}
            >
              <BookOpen size={18} />
              <span>Readings</span>
            </Link>
            <Link 
              to="/music" 
              className={`flex items-center space-x-2 border-b-2 ${isActive('/music')} pb-1 hover:text-zinc-300 transition`}
            >
              <Music size={18} />
              <span>Music</span>
            </Link>
          </div>
        </div>
      </div>
    </nav>
  )
}

export default Navbar