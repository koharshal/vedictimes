import React from 'react'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import Navbar from './components/Navbar'
import Home from './pages/Home'
import Writings from './pages/Writings'
import Readings from './pages/Readings'
import Music from './pages/Music'

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-zinc-900 text-white">
        <Navbar />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/writings" element={<Writings />} />
          <Route path="/readings" element={<Readings />} />
          <Route path="/music" element={<Music />} />
        </Routes>
      </div>
    </Router>
  )
}

export default App